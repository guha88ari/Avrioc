package com.avroc.spark.stream.instream

import com.avroc.spark.stream.subscribe_topic.Subscriber._
import com.avroc.spark.stream.util.Helper._
import com.avroc.spark.stream.util.SparkSessionUtil._
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.{col, count, from_json, unix_timestamp}
import org.apache.spark.sql.types.{StringType, TimestampType}

object ProducerStreamReader extends Serializable {

  @transient lazy val logger:Logger=Logger.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {

    val spark = getSession()
    val kafkaSubscribe=getStreamData(spark,topic1)

    kafkaSubscribe.printSchema()


    val inputDS=kafkaSubscribe.select(from_json(col("value").cast("string"),logSchema).as("value"))

    inputDS.printSchema()

    val in_df=inputDS.select(col("value.user_id"),col("value.item_id"),col("value.interaction_type")
    ,col("value.timestamp"))



    val tempDF=in_df.withColumn("timestamp",unix_timestamp(col("timestamp").cast(StringType),"MM/dd/yyyy hh:mm:ss aa").cast(TimestampType)).
      withWatermark("timestamp","1 minutes").
      groupBy("user_id","timestamp")
      .agg(count("interaction_type").as("count_interaction"))

    tempDF.printSchema()



    val kafkaSink_user=tempDF.selectExpr("user_id as key",
      """
        |to_json(named_struct('user_id',user_id,
        |'count_interaction',count_interaction,
        |'timestamp',timestamp
        |)
        |) as value
      """.stripMargin
    )

    val stage_query = kafkaSink_user
      .writeStream
      .queryName("Stage 1")
      .format("kafka")
      .option("kafka.bootstrap.servers", "localhost:9092")
      .option("topic", topic2)
      .outputMode("append")
      .option("checkpointLocation", "chk-point-dir")

      .start()


    logger.info("Listening and writing to Kafka stage 2")





    val temp_df1=in_df.withColumn("timestamp",unix_timestamp(col("timestamp").cast(StringType),"MM/dd/yyyy hh:mm:ss aa").cast(TimestampType))
      .withWatermark("timestamp","1 minutes")
      .groupBy("item_id","interaction_type","timestamp").
      agg(count("interaction_type").as("count_interaction"))
    temp_df1.printSchema()


    val kafkaSink_item=temp_df1.selectExpr("item_id as key",
      """
        |to_json(named_struct('item_id',item_id,
        |"interaction_type",interaction_type,
        |'count_interaction',count_interaction,
        |'timestamp',timestamp
        |)
        |) as value
      """.stripMargin
    )

    val stage_query2 = kafkaSink_item
      .writeStream
      .queryName("stage_query2")
      .format("kafka")
      .option("kafka.bootstrap.servers", "localhost:9092")
      .option("topic", topic3)
      .outputMode("append")
      .option("checkpointLocation", "chk-point-dir1")
      .start()

    stage_query.awaitTermination()




    stage_query2.awaitTermination()
    spark.streams.awaitAnyTermination()


  }


}
