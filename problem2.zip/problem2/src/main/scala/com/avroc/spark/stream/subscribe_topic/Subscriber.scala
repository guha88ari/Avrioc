package com.avroc.spark.stream.subscribe_topic

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql._

object Subscriber {

  def getStreamData(spark:SparkSession,topic: String): DataFrame = {
    val in_df=spark.readStream.format("kafka")
      .option("kafka.bootstrap.servers","localhost:9092")
      .option("subscribe",topic)
      .option("startingOffsets","earliest")
      .load()
    in_df
  }

}
