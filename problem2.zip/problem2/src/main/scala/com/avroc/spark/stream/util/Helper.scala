package com.avroc.spark.stream.util

import org.apache.spark.sql.types._

object Helper {

  val logSchema = StructType(List(
    StructField("user_id", StringType),
    StructField("item_id", StringType),
    StructField("interaction_type", StringType),
    StructField("timestamp", LongType)))

  val stageSchema = StructType(List(
    StructField("user_id", StringType),
    StructField("count_interaction", StringType),
    StructField("timestamp", TimestampType)))

  val topic1="aviroc"
  val topic2="stage"
  val topic3="stage2"
  val topic4="final1"
  val topic5="final2"

}
