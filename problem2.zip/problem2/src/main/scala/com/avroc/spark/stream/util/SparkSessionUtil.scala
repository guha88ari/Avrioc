package com.avroc.spark.stream.util
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
object SparkSessionUtil {
  def getSession(): SparkSession = {
    val conf = new SparkConf()
    conf.set("spark.master", "local[*]")
    conf.set("spark.sql.session.timeZone", "UTC")
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true")
    conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    val session = SparkSession.builder().config(conf).getOrCreate()
    session.sparkContext.setLogLevel("ERROR")
    session
  }
}
