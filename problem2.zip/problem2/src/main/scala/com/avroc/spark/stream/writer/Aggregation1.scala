package com.avroc.spark.stream.writer

import com.avroc.spark.stream.subscribe_topic.Subscriber.getStreamData
import com.avroc.spark.stream.util.Helper.stageSchema
import com.avroc.spark.stream.util.SparkSessionUtil.getSession
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._

object Aggregation1 {
  @transient lazy val logger:Logger=Logger.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {

    val spark = getSession()
    val kafkaSubscribe1=getStreamData(spark,"stage")

    kafkaSubscribe1.printSchema()


    val inputDS1=kafkaSubscribe1.select(from_json(col("value").cast("string"),stageSchema).as("value"))

    inputDS1.printSchema()

    val in_df=inputDS1.select(col("value.user_id"),col("value.count_interaction")
      ,col("value.timestamp"))




    val final_df=in_df.withWatermark("timestamp","1 minutes").groupBy("user_id","timestamp")
      .agg(avg("count_interaction").as("avg_interaction"))

    val kafkaSink=final_df.selectExpr("user_id as key",
      """
        |to_json(named_struct('user_id',user_id,
        |'avg_interaction',avg_interaction,
        |'timestamp',timestamp
        |)
        |) as value
      """.stripMargin
    )


    val finalStage = kafkaSink
      .writeStream

      .format("console")
      .outputMode("update")
      .start()
    logger.info("Listening and writing to Kafka")
    finalStage.awaitTermination()


    spark.streams.awaitAnyTermination()


  }
}
