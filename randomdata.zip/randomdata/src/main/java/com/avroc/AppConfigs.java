package com.avroc;

public class AppConfigs {

    public final static String applicationID = "random_data_generator";
    public final static String bootstrapServers = "localhost:9092";
}
