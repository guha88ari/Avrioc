package com.avroc;


import com.avroc.datagen.LogDataGenerator;
import com.avroc.types.LogData;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.concurrent.atomic.AtomicBoolean;

public class RunnableProducer implements Runnable {
    private static final Logger logger = LogManager.getLogger(RunnableProducer.class);
    private final AtomicBoolean stopper = new AtomicBoolean(false);
    private KafkaProducer<String, LogData> producer;
    private String topicName;
    private LogDataGenerator logDataGenerator;
    private int produceSpeed;
    private int id;

    RunnableProducer(int id, KafkaProducer<String, LogData> producer, String topicName, int produceSpeed) {
        this.id = id;
        this.producer = producer;
        this.topicName = topicName;
        this.produceSpeed = produceSpeed;
        this.logDataGenerator = LogDataGenerator.getInstance();
    }
    @Override
    public void run() {
        try {
            logger.info("Starting producer thread - " + id);
            while (!stopper.get()) {
                LogData posLogData = logDataGenerator.getInvoice();
                producer.send(new ProducerRecord<>(topicName, posLogData.getInterationType(), posLogData));
                Thread.sleep(produceSpeed);
            }

        } catch (Exception e) {
            logger.error("Exception in Producer thread - " + e.getMessage());
            throw new RuntimeException(e);
        }

    }

    void shutdown() {
        logger.info("Shutting down producer thread - " + id);
        stopper.set(true);

    }
}