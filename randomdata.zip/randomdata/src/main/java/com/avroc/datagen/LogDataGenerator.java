
package com.avroc.datagen;

import com.avroc.types.LogData;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


import java.io.File;
import java.util.Random;

public class LogDataGenerator {
    private static final Logger logger = LogManager.getLogger(LogDataGenerator.class);
    public static final LogDataGenerator ourInstance = new LogDataGenerator();
    public final Random random;
    public final Random uid;
    public final Random id;
    public final LogData[] products;
    final String[] click_type = {"Click", "Purchase", "view"};
    final String[] item_code = {"I100", "I101", "I102","I103",""};
    public static LogDataGenerator getInstance() {
        return ourInstance;
    }

    private LogDataGenerator() {
        String DATAFILE = "src/main/resources/data/log.json";
        ObjectMapper mapper = new ObjectMapper();
        random = new Random();
        uid = new Random();
        id=new Random();
        try {
            products = mapper.readValue(new File(DATAFILE), LogData[].class);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public int getIndex() {
        return random.nextInt(2);
    }
    public int getUserId() {
        return uid.nextInt(65) ;
    }

    public int getItemid() {
        System.out.println(id.nextInt(900) + 100);
    return id.nextInt(900) + 100;
    }

    public LogData getInvoice (){
        LogData user_id = products[getIndex()];
        user_id.setUserId(Integer.toString(getUserId()));
        user_id.setItemId("I".concat(Integer.toString(getItemid())));
        user_id.setInterationType(click_type[getIndex()]);
        user_id.setTimestamp(System.currentTimeMillis());
        logger.debug(user_id);
        return user_id;
    }
}