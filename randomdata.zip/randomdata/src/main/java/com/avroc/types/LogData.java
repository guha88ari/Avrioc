package com.avroc.types;

import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "user_id",
        "item_id",
        "interaction_type",
        "timestamp"
})
public class LogData {

    @JsonProperty("user_id")
    private String user_id;
    @JsonProperty("item_id")
    private String item_id;
    @JsonProperty("interaction_type")
    private String interaction_type;
    @JsonProperty("timestamp")
    private Long timestamp;

    @JsonProperty("user_id")
    public String getUserId() {
        return user_id;
    }

    @JsonProperty("user_id")
    public void setUserId(String UserId) {
        this.user_id = UserId;
    }

    @JsonProperty("item_id")
    public String getItemId() {
        return item_id;
    }

    @JsonProperty("item_id")
    public void setItemId(String item_id) {
        this.item_id = item_id;
    }

    @JsonProperty("interaction_type")
    public String getInterationType() {
        return interaction_type;
    }

    @JsonProperty("interaction_type")
    public void setInterationType(String interaction_type) {
        this.interaction_type = interaction_type;
    }

    @JsonProperty("timestamp")
    public Long getTimestamp() {
        return timestamp;
    }

    @JsonProperty("timestamp")
    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }



    @Override
    public String toString() {
        return new ToStringBuilder(this).append("user_id", user_id).
                append("item_id", item_id).append("interaction_type", interaction_type).
                append("timestamp", timestamp).toString();
    }

}